stopifnot(is.function(hello))
